﻿from src.retrieval.hybrid_retriever import retrieve
from src.llm.answer_generator import generate_answer
from src.rewrite.query_type_classifier import classify_query_type
from src.graph.graph_retriever import graph_retrieve
from src.llm.graph_answer_generator import generate_graph_answer

def keep_best_evidence(results):
    if not results:
        return []

    top = results[0]

    if top.get("fine_text") and top.get("citation"):
        return [top]

    return results[:5]

def answer_question(question, top_k=5):
    query_type = classify_query_type(question)

    if query_type in ["exception_question", "ambiguous_scenario"]:
        gout = graph_retrieve(question, top_k=top_k)
        results = gout.get("results", [])
        answer = generate_graph_answer(question, results, query_type)

        return {
            "question": question,
            "query_type": query_type,
            "answer": answer,
            "rewrite": {
                "original_query": question,
                "mode": "graphrag",
                "query_concepts": gout.get("query_concepts", [])
            },
            "sources": results,
            "retrieved_count": len(results)
        }

    out = retrieve(question, top_k=top_k)
    results = keep_best_evidence(out.get("results", []))
    answer = generate_answer(question, results)

    return {
        "question": question,
        "query_type": query_type,
        "answer": answer,
        "rewrite": out.get("rewrite", {}),
        "sources": results,
        "retrieved_count": len(results)
    }
