﻿import re
import unicodedata

def strip_accents(text):
    text = str(text or "").lower().replace("đ", "d")
    text = unicodedata.normalize("NFD", text)
    return "".join(c for c in text if unicodedata.category(c) != "Mn")

def normalize(text):
    text = strip_accents(text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())

def has_any(q, terms):
    return any(t in q for t in terms)

def classify_query_type(query):
    q = normalize(query)

    emergency_terms = [
        "xe cap cuu",
        "xe uu tien",
        "xe chua chay",
        "xe cong an",
        "xe quan su",
        "doan xe uu tien",
        "nhuong duong cho xe cap cuu",
        "nhuong duong cho xe uu tien"
    ]

    exception_terms = [
        "mien tru",
        "mien phat",
        "khong bi phat",
        "bat kha khang",
        "cap cuu",
        "phat nguoi",
        "camera",
        "tinh the cap thiet"
    ]

    ambiguous_terms = [
        "den xanh con",
        "chom qua vach",
        "chua kip",
        "den tin hieu hong",
        "ca 3 mau",
        "bien bao bi cay che",
        "bi che khuat",
        "co bi coi la",
        "co duoc coi la",
        "tinh huong",
        "khong co cho tranh",
        "duong tac",
        "tat may",
        "dung chan day",
        "nam ngu",
        "dang do dung noi quy dinh"
    ]

    rule_terms = [
        "quy dinh",
        "duoc quyen",
        "co gia tri",
        "thay the",
        "trong bao lau",
        "thi lai",
        "giu xe",
        "bien ban",
        "khong ky bien ban",
        "vneid",
        "tich hop",
        "the nao",
        "nhu the nao",
        "khac nhau"
    ]

    penalty_terms = [
        "phat bao nhieu",
        "muc phat",
        "phat tien",
        "bao nhieu tien",
        "mat bao nhieu",
        "may trieu",
        "may lit",
        "xu phat",
        "bi phat",
        "phat khong",
        "bi bat",
        "mat tien"
    ]

    if has_any(q, emergency_terms) and has_any(q, exception_terms + ["vuot den do", "den do"]):
        return "exception_question"

    if has_any(q, exception_terms) and has_any(q, ["vuot den do", "den do", "phat nguoi"]):
        return "exception_question"

    if has_any(q, ambiguous_terms):
        return "ambiguous_scenario"

    if has_any(q, penalty_terms):
        return "penalty_single_hop"

    if has_any(q, rule_terms):
        return "rule_question"

    return "general_question"
