﻿from src.retrieval.hybrid_retriever import retrieve
from src.llm.answer_generator import generate_answer

def keep_best_evidence(results):
    if not results:
        return []

    top = results[0]

    if top.get("fine_text") and top.get("citation"):
        return [top]

    return results[:5]

def answer_question(question, top_k=5):
    out = retrieve(question, top_k=top_k)
    results = keep_best_evidence(out.get("results", []))

    answer = generate_answer(question, results)

    return {
        "question": question,
        "answer": answer,
        "rewrite": out.get("rewrite", {}),
        "sources": results,
        "retrieved_count": len(results)
    }