﻿import sys
from pathlib import Path
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.rag.pipeline import answer_question

st.set_page_config(
    page_title="Traffic Law RAG",
    page_icon="🚦",
    layout="wide"
)

if "messages" not in st.session_state:
    st.session_state.messages = []

if "debug" not in st.session_state:
    st.session_state.debug = []

st.sidebar.title("Debug RAG")

for i, d in enumerate(reversed(st.session_state.debug), 1):
    with st.sidebar.expander(f"{i}. {d['question'][:40]}"):
        st.write("Legal queries")
        for q in d.get("legal_queries", []):
            st.write("-", q)

        st.write("Retrieved:", d.get("retrieved_count", 0))

        st.write("Top sources")
        for s in d.get("sources", [])[:5]:
            st.write("-", s.get("citation", ""))

st.title("🚦 Tra cứu luật giao thông Việt Nam")
st.caption("RAG tra cứu Nghị định 168/2024/NĐ-CP từ căn cứ pháp lý đã truy xuất.")

for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

q = st.chat_input("Nhập câu hỏi về luật giao thông...")

if q:
    st.session_state.messages.append({"role": "user", "content": q})

    with st.chat_message("user"):
        st.markdown(q)

    res = answer_question(q)

    with st.chat_message("assistant"):
        st.markdown(res["answer"])

    st.session_state.messages.append({
        "role": "assistant",
        "content": res["answer"]
    })

    st.session_state.debug.append({
        "question": q,
        "legal_queries": res.get("rewrite", {}).get("legal_queries", []),
        "retrieved_count": res.get("retrieved_count", 0),
        "sources": res.get("sources", [])
    })

    st.rerun()
