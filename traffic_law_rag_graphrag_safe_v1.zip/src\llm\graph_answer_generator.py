﻿def clean_text(text):
    return " ".join(str(text or "").split())

def format_sources(results):
    lines = []

    for i, r in enumerate(results, 1):
        citation = clean_text(r.get("citation", ""))
        fine = clean_text(r.get("fine_text", ""))
        content = clean_text(r.get("content", ""))

        if fine:
            lines.append(f"{i}. {citation}: {fine}. Nội dung: {content}")
        else:
            lines.append(f"{i}. {citation}: {content}")

    return "\n".join(lines)

def generate_graph_answer(question, results, query_type):
    if not results:
        if query_type == "exception_question":
            return (
                "Đây là tình huống có yếu tố ngoại lệ hoặc nhiều điều kiện. "
                "Tôi chưa tìm thấy đủ căn cứ pháp lý trực tiếp trong dữ liệu hiện có để kết luận chắc chắn. "
                "Cần bổ sung thêm quy định liên quan đến xe ưu tiên, phạt nguội, miễn/trừ xử phạt hoặc tình huống bất khả kháng."
            )

        if query_type == "ambiguous_scenario":
            return (
                "Tình huống này còn mơ hồ nên tôi chưa đủ căn cứ pháp lý để kết luận. "
                "Cần làm rõ thời điểm xe qua vạch, trạng thái đèn tín hiệu, camera ghi nhận và tình tiết thực tế."
            )

        return "Tôi chưa tìm thấy căn cứ pháp lý phù hợp trong dữ liệu hiện có để kết luận."

    src = format_sources(results[:5])

    if query_type == "exception_question":
        return (
            "Đây là tình huống có yếu tố ngoại lệ hoặc nhiều điều kiện. "
            "Tôi tìm thấy một số căn cứ pháp lý liên quan, nhưng chưa có căn cứ trực tiếp trong dữ liệu hiện có để khẳng định chắc chắn được miễn phạt hoặc bị phạt.\n\n"
            "Các căn cứ liên quan:\n"
            f"{src}\n\n"
            "Kết luận: Chưa đủ căn cứ pháp lý trực tiếp để kết luận chắc chắn. Cần bổ sung thêm quy định hoặc hướng dẫn về xe ưu tiên, phạt nguội và trường hợp miễn/trừ xử phạt."
        )

    if query_type == "ambiguous_scenario":
        return (
            "Tình huống này phụ thuộc vào thời điểm xe qua vạch, trạng thái đèn tín hiệu và dữ liệu ghi nhận thực tế. "
            "Tôi tìm thấy một số căn cứ liên quan, nhưng chưa đủ để kết luận trực tiếp.\n\n"
            "Các căn cứ liên quan:\n"
            f"{src}\n\n"
            "Kết luận: Chưa đủ căn cứ pháp lý trực tiếp để kết luận. Cần làm rõ thêm tình tiết thực tế."
        )

    return src
