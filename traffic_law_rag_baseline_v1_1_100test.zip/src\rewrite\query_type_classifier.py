﻿import re
import unicodedata

def strip_accents(text):
    text = str(text or "").lower().replace("đ", "d")
    text = unicodedata.normalize("NFD", text)
    return "".join(c for c in text if unicodedata.category(c) != "Mn")

def normalize(text):
    text = strip_accents(text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())

def classify_query_type(query):
    q = normalize(query)

    exception_terms = [
        "xe cap cuu", "xe uu tien", "nhuong duong",
        "mien tru", "bat kha khang", "cap cuu",
        "phat nguoi", "camera"
    ]

    ambiguous_terms = [
        "den xanh con", "chom qua vach", "chua kip", "den tin hieu hong",
        "bien bao bi cay che", "co bi coi la", "co duoc coi la",
        "tinh huong", "khong co cho tranh", "duong tac"
    ]

    rule_terms = [
        "quy dinh", "duoc quyen", "co gia tri", "thay the",
        "trong bao lau", "thi lai", "giu xe", "bien ban",
        "khong ky bien ban", "vneid", "tich hop"
    ]

    penalty_terms = [
        "phat bao nhieu", "muc phat", "phat tien", "bao nhieu tien",
        "mat bao nhieu", "may trieu", "may lit", "xu phat",
        "bi phat", "phat khong"
    ]

    if any(x in q for x in exception_terms):
        return "exception_question"

    if any(x in q for x in ambiguous_terms):
        return "ambiguous_scenario"

    if any(x in q for x in penalty_terms):
        return "penalty_single_hop"

    if any(x in q for x in rule_terms):
        return "rule_question"

    return "general_question"
