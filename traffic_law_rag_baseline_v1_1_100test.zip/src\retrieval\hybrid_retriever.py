﻿import re
import unicodedata

from src.rewrite.query_rewriter import rewrite_query
from src.retrieval.bm25_search import search_bm25
from src.retrieval.exact_search import exact_search

STOP = {
    "xe", "may", "oto", "o", "to", "phat", "bao", "nhieu", "co", "bi",
    "khong", "la", "thi", "sao", "the", "nao", "muc", "tien", "hoi",
    "nguoi", "dieu", "khien", "quy", "dinh"
}

CONCEPTS = {
    "passenger_cabin": ["buong lai", "so luong"],
    "lane_change": ["chuyen lan"],
    "yielding": ["nhuong duong"],
    "intersection": ["giao nhau"],
    "accident_escape": ["tai nan", "va cham", "khong dung", "khong giu nguyen hien truong", "khong tro giup", "bo chay", "chay tron"],
    "traffic_light": ["den tin hieu", "den giao thong", "vuot den", "chay den", "khong chap hanh hieu lenh cua den tin hieu"],
    "green_light": ["den xanh"],
    "red_light": ["den do"],
    "yellow_light": ["den vang"],
    "horn_time": ["su dung coi", "bam coi", "22 gio", "05 gio", "5 gio"],
    "highway": ["cao toc"]
}

def strip_accents(text):
    text = str(text or "").lower().replace("đ", "d")
    text = unicodedata.normalize("NFD", text)
    return "".join(c for c in text if unicodedata.category(c) != "Mn")

def normalize(text):
    text = strip_accents(text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())

def tokens(text):
    return [t for t in normalize(text).split() if len(t) >= 2 and t not in STOP]

def detect_vehicle(query):
    q = normalize(query)

    if any(x in q for x in ["o to", "oto", "xe hoi", "xe con", "xe tai", "xe khach"]):
        return "car"

    if any(x in q for x in ["xe may", "mo to", "moto", "xe gan may", "sh", "wave", "vision"]):
        return "motorbike"

    if "xe dap" in q:
        return "bicycle"

    if "nguoi di bo" in q:
        return "pedestrian"

    return "unknown"

def active_concepts(text):
    t = normalize(text)
    found = set()

    for name, terms in CONCEPTS.items():
        if any(term in t for term in terms):
            found.add(name)

    return found

def legal_query_ok(original, legal_query):
    original_concepts = active_concepts(original)
    query_concepts = active_concepts(legal_query)

    must_keep = {
        "passenger_cabin",
        "lane_change",
        "yielding",
        "accident_escape",
        "traffic_light",
        "green_light",
        "red_light",
        "yellow_light",
        "horn_time"
    }

    for c in original_concepts & must_keep:
        if c in ["red_light", "yellow_light"]:
            if "traffic_light" not in query_concepts and c not in query_concepts:
                return False
            continue

        if c not in query_concepts:
            return False

    if "highway" not in original_concepts and "highway" in query_concepts:
        return False

    return True

def evidence_supports(original, row):
    q_vehicle = detect_vehicle(original)
    r_vehicle = row.get("vehicle_group", "")

    if q_vehicle != "unknown" and r_vehicle and q_vehicle != r_vehicle:
        return False

    q_concepts = active_concepts(original)
    content_concepts = active_concepts(row.get("content", ""))

    if "green_light" in q_concepts:
        return False

    must_support = {
        "passenger_cabin",
        "lane_change",
        "yielding",
        "accident_escape",
        "traffic_light",
        "red_light",
        "yellow_light",
        "horn_time"
    }

    for c in q_concepts & must_support:
        if c in ["red_light", "yellow_light"]:
            if "traffic_light" not in content_concepts and c not in content_concepts:
                return False
            continue

        if c not in content_concepts:
            return False

    if "highway" not in q_concepts and "highway" in content_concepts:
        return False

    return True

def support_score(original, legal_query, row):
    content = normalize(row.get("content", ""))
    q_terms = set(tokens(original))
    l_terms = set(tokens(legal_query))

    q_overlap = len([t for t in q_terms if t in content])
    l_overlap = len([t for t in l_terms if t in content])

    return q_overlap + l_overlap

def retrieve(query, top_k=5):
    exact_results = [
        r for r in exact_search(query, top_k=top_k)
        if evidence_supports(query, r)
    ]

    if exact_results:
        return {
            "query": query,
            "rewrite": {
                "original_query": query,
                "vehicle_group": detect_vehicle(query),
                "legal_queries": [query],
                "mode": "exact_first"
            },
            "results": exact_results[:top_k]
        }

    rewrite = rewrite_query(query)
    legal_queries = [
        q for q in rewrite.get("legal_queries", [query])
        if legal_query_ok(query, q)
    ]

    if not legal_queries:
        legal_queries = [query]

    merged = {}

    for qi, legal_query in enumerate(legal_queries):
        for row in search_bm25(legal_query, top_k=15):
            if not evidence_supports(query, row):
                continue

            sup = support_score(query, legal_query, row)
            if sup < 4:
                continue

            key = row.get("citation", "")
            if not key:
                continue

            score = row.get("score", 0)
            score += sup * 6
            score += max(0, 8 - qi)

            item = dict(row)
            item["score"] = float(score)
            item["source_query"] = legal_query
            item["rewrite"] = rewrite

            if key not in merged or item["score"] > merged[key]["score"]:
                merged[key] = item

    results = sorted(merged.values(), key=lambda x: x["score"], reverse=True)

    return {
        "query": query,
        "rewrite": rewrite,
        "results": results[:top_k]
    }
