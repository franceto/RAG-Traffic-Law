﻿from src.retrieval.hybrid_retriever import retrieve
from src.llm.answer_generator import generate_answer
from src.rewrite.query_type_classifier import classify_query_type

def keep_best_evidence(results):
    if not results:
        return []

    top = results[0]

    if top.get("fine_text") and top.get("citation"):
        return [top]

    return results[:5]

def cautious_no_answer(question, query_type):
    if query_type == "exception_question":
        return (
            "Đây là tình huống có yếu tố ngoại lệ hoặc nhiều điều kiện. "
            "Tôi chưa tìm thấy đủ căn cứ pháp lý trực tiếp trong dữ liệu hiện có để kết luận chắc chắn. "
            "Cần truy xuất thêm các quy định liên quan đến xe ưu tiên, phạt nguội, miễn/trừ xử phạt hoặc tình huống bất khả kháng."
        )

    if query_type == "ambiguous_scenario":
        return (
            "Tình huống này còn mơ hồ nên tôi chưa đủ căn cứ pháp lý để kết luận. "
            "Cần làm rõ thêm thời điểm xe qua vạch, trạng thái đèn tín hiệu, biển báo/camera ghi nhận và tình tiết thực tế."
        )

    return "Tôi chưa tìm thấy căn cứ pháp lý phù hợp trong dữ liệu hiện có để kết luận."

def answer_question(question, top_k=5):
    query_type = classify_query_type(question)
    out = retrieve(question, top_k=top_k)
    results = keep_best_evidence(out.get("results", []))

    if not results and query_type in ["exception_question", "ambiguous_scenario"]:
        answer = cautious_no_answer(question, query_type)
    else:
        answer = generate_answer(question, results)

    return {
        "question": question,
        "query_type": query_type,
        "answer": answer,
        "rewrite": out.get("rewrite", {}),
        "sources": results,
        "retrieved_count": len(results)
    }
